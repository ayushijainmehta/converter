package com.example.demo;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
public class propertyToText
{
	public static Resource convert(String resource,FileSystemStorageService storageService) throws Exception
	{   int count=1;
	System.out.print(resource);
		Scanner scanner=new Scanner(System.in);
	    PrintWriter out = new PrintWriter("D:\\converted.txt");
	  
	    String fileName="Config";
	    FileReader reader=new FileReader(resource);  
	    Properties properties=new Properties();  
	    properties.load(reader);
	    //System.out.print("Enter property to be fetched ");
	   // String property=scanner.next();
	    String email=properties.getProperty("email");
	    String[] emailSplit = email.split(",");
	    List<String> emailList = Arrays.asList(emailSplit);
	    Iterator itr=emailList.iterator();  
	    while(itr.hasNext()){ 

		  // System.out.println(count+". "+itr.next());
	   out.println(count+". "+itr.next());
	    count++;
	     } 
	   
	    out.close();
		Resource file = storageService.loadAsResource("D:\\email.txt");
	return file;
	}
}
