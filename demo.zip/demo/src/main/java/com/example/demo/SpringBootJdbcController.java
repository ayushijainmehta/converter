package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RestController;

@Controller
@Resource(name = "defaultConversionService")
public class SpringBootJdbcController {
	@Autowired
	JdbcTemplate jdbc;
@Autowired
EmailController sendMail;
	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public String index(ModelMap model, @RequestParam String email, @RequestParam String psw) throws AddressException, MessagingException, IOException {
		jdbc.update("INSERT INTO user (email, password) VALUES (?, ?)", email, psw);
		sendMail.sendmail();
		return "confirm";
	}
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public  String login(ModelMap model,@RequestParam String name, @RequestParam String password) {
	List list=new ArrayList();

	String sql = "SELECT email FROM user where email='"+name+"'";
	

    jdbc.query(sql, new ResultSetExtractor() {
			public List extractData(ResultSet rs) throws SQLException {
				while (rs.next()) {
					String name = rs.getString("email");
					
					System.out.println(name);
                  list.add(name);
				}
				
				return list;
			}
		}
     );
	if(list.isEmpty())
	{
		return "home";	    // when resultset empty in case of even username not same
	}
if(name.equals(list.get(0)))
{
System.out.print("successfull");

return "dash";
}
else
{
	
	return "home";
}
	}

}
