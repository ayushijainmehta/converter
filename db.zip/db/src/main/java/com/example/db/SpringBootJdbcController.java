package com.example.db;

import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.web.bind.annotation.RestController;  
@RestController 
@Resource(name = "defaultConversionService")
public class SpringBootJdbcController {  
    @Autowired  
    JdbcTemplate jdbc;    
    @RequestMapping("/insert")  
    public String index(){  
    	
        jdbc.execute("insert into user(name,email)values('javatpoint','java@javatpoint.com')");  
        return "data inserted Successfully";  
    }  
}  
