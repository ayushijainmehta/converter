package com.example.upload;

public class Constants {
	
	public static final String UPLOAD_LOCATION = "C:\\java-exec\\upload-dir\\";

}