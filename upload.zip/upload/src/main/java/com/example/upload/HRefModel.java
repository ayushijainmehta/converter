package com.example.upload;

public class HRefModel {
	
	private String href;
	private String hrefText;

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	public String getHrefText() {
		return hrefText;
	}

	public void setHrefText(String hrefText) {
		this.hrefText = hrefText;
	}

}